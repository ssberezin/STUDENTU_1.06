namespace CodeFixtureTests.Filters
{
    public class UserFilterOptions
    {
        public string Name { get; set; }
    }
}